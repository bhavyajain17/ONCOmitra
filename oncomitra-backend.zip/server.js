'use strict';
const { openDb } = require('./src/db');
const { createApp } = require('./src/app');
const { seedIfEmpty } = require('./src/seed');

const prod = process.env.NODE_ENV === 'production';
const db = openDb(process.env.DB_FILE || 'oncomitra.db');
seedIfEmpty(db).then(users => {
  if (users) console.log('First run: demo accounts (shown once)\n' + users.map(x => `  ${x.username.padEnd(12)} ${x.role.padEnd(9)} ${x.password}`).join('\n'));
  const port = Number(process.env.PORT) || 3000;
  createApp({ db, prod }).listen(port, '127.0.0.1', () => console.log(`ONCOmitra on http://127.0.0.1:${port}` + (prod ? '' : '  (dev mode: cookies not Secure)')));
});
