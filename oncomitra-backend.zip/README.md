# ONCOmitra backend (hardened demo)

Node.js + Express + SQLite. The existing ONCOmitra page is served from `public/` and talks to `/api/*`.

## Run
```
npm install
npm start            # first run creates oncomitra.db and prints demo logins ONCE (random passwords)
# open http://127.0.0.1:3000
npm test             # 13 automated security tests
```
Environment: `PORT`, `DB_FILE`, `NODE_ENV=production` (Secure cookies + HTTPS upgrade; serve behind HTTPS), `TRUST_PROXY=1` when behind a reverse proxy.

## Roles (enforced on the server)
| Role | Can do |
|---|---|
| asha | create screenings, see and add notes to **only their own** patients |
| clinician | see all patients, add notes, change stage, export CSV |
| admin | everything above + read the audit log |

## Security controls
scrypt password hashing (N=65536), random session tokens (only SHA-256 stored), HttpOnly + SameSite=Strict cookies, 30-min idle / 8-h absolute session expiry, 5-failure account lockout (15 min) + per-IP login limit, generic login errors, CSRF header + Origin check, parameterized SQL, input validation, 20 KB body limit, helmet headers + CSP, no stack traces, audit log of logins, views, changes, exports and denied actions.

## Known limits (do before real patient data)
Risk score is computed in the browser and only range-checked by the server; no image storage yet; SQLite file is not encrypted at rest; no password-change/reset or user-admin screens; CSP still allows inline scripts; no backups or log shipping; needs HTTPS hosting and a privacy/compliance review.
