'use strict';
const crypto = require('node:crypto');
const { openDb, hashPassword } = require('./db');

const VILLAGES = ['Ambala City', 'Kaithal', 'Yamunanagar', 'Panchkula', 'Karnal', 'Kurukshetra'];
const HABITS = ['None', 'Occasional', 'Regular (smokeless)', 'Regular (smoked)', 'Both'];
const SYMPTOMS = ['White/red patch', 'Non-healing ulcer (>2wks)', 'Difficulty chewing', 'Restricted mouth opening', 'Pain while swallowing', 'Lump in neck/mouth'];
const NAMES = ['Rekha Devi', 'Suman Kumari', 'Anita Singh', 'Geeta Kumar', 'Kavita Yadav', 'Rajesh Sharma', 'Suresh Verma', 'Mahesh Rani'];

// users: [{username, displayName, role, password}] ; passwords are supplied by the caller, never hardcoded here
async function seed(db, users, { demoPatients = true } = {}) {
  const ins = db.prepare('INSERT INTO users(username,display_name,role,pw_hash) VALUES(?,?,?,?)');
  const ids = {};
  for (const u of users) ids[u.username] = Number(ins.run(u.username, u.displayName, u.role, await hashPassword(u.password)).lastInsertRowid);
  const ashas = users.filter(u => u.role === 'asha');
  if (demoPatients && ashas.length) {
    const add = db.prepare('INSERT INTO patients VALUES(?,?,?,?,?,?,?,?,?,?,?)');
    NAMES.forEach((n, i) => add.run('p' + crypto.randomBytes(6).toString('hex'), n, 30 + i * 5, i % 3 ? 'Female' : 'Male',
      VILLAGES[i % 6], ids[ashas[i % ashas.length].username], 10 + i * 11, HABITS[i % 5], i % 7,
      JSON.stringify(SYMPTOMS.filter((_, k) => (i + k) % 3 === 0)), Date.now() - i * 86400e3));
  }
  return ids;
}

async function seedIfEmpty(db) {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c) return null;
  const pw = () => crypto.randomBytes(9).toString('base64url');
  const users = [
    { username: 'admin', displayName: 'Programme Admin', role: 'admin', password: pw() },
    { username: 'clinician', displayName: 'Dr. Rao', role: 'clinician', password: pw() },
    { username: 'asha.sunita', displayName: 'Sunita Devi', role: 'asha', password: pw() },
    { username: 'asha.radha', displayName: 'Radha Kumari', role: 'asha', password: pw() },
  ];
  await seed(db, users);
  return users;
}
module.exports = { seed, seedIfEmpty };

if (require.main === module) {
  const db = openDb(process.env.DB_FILE || 'oncomitra.db');
  seedIfEmpty(db).then(u => console.log(u ? 'Demo accounts created (shown once, change or delete for real use):\n' +
    u.map(x => `  ${x.username.padEnd(12)} ${x.role.padEnd(9)} ${x.password}`).join('\n') : 'Database already has users; nothing seeded.'));
}
