'use strict';
const Database = require('better-sqlite3');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);
const P = { N: 65536, r: 8, p: 1, maxmem: 256 * 1024 * 1024 };

function openDb(file = ':memory:') {
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('admin','clinician','asha')), pw_hash TEXT NOT NULL,
  failed INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  created INTEGER NOT NULL, last_seen INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS patients(id TEXT PRIMARY KEY, name TEXT NOT NULL, age INTEGER NOT NULL, gender TEXT NOT NULL,
  village TEXT NOT NULL, asha_id INTEGER NOT NULL REFERENCES users(id), risk INTEGER NOT NULL, habit TEXT NOT NULL,
  stage_idx INTEGER NOT NULL, symptoms TEXT NOT NULL, updated INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id),
  author TEXT NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts INTEGER NOT NULL, username TEXT, action TEXT NOT NULL,
  patient_id TEXT, detail TEXT);`);
  return db;
}

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = await scrypt(pw, salt, 64, P);
  return `scrypt$${P.N}$${P.r}$${P.p}$${salt.toString('base64')}$${h.toString('base64')}`;
}

let dummy;
async function verifyPassword(pw, stored) {
  // Unknown users are checked against a dummy hash so timing does not reveal which usernames exist.
  stored = stored || (dummy ||= await hashPassword('dummy-password-for-timing'));
  const [, N, r, p, salt, hash] = stored.split('$');
  const want = Buffer.from(hash, 'base64');
  const got = await scrypt(pw, Buffer.from(salt, 'base64'), want.length, { N: +N, r: +r, p: +p, maxmem: P.maxmem });
  return crypto.timingSafeEqual(got, want);
}

module.exports = { openDb, hashPassword, verifyPassword };
