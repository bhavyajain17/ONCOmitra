'use strict';
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('node:crypto');
const path = require('node:path');
const { verifyPassword } = require('./db');

const H = t => crypto.createHash('sha256').update(t).digest('hex');
const IDLE = 30 * 60e3, ABSOLUTE = 8 * 3600e3, MAX_FAIL = 5, LOCK = 15 * 60e3;
// Permissions are decided here, on the server. The browser's role dropdown has no effect on them.
const PERMS = {
  admin: { all: 1, stage: 1, export: 1, audit: 1 },
  clinician: { all: 1, stage: 1, export: 1 },
  asha: {},
};
const clean = (v, min, max) => {
  if (typeof v !== 'string') return null;
  const s = v.replace(/[\u0000-\u001f\u007f]/g, ' ').trim();
  return s.length >= min && s.length <= max ? s : null;
};

function createApp({ db, prod = false, loginRateMax = 10 }) {
  const app = express();
  app.set('trust proxy', process.env.TRUST_PROXY ? 1 : false);
  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ['https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        frameSrc: ['https://www.youtube-nocookie.com'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"], baseUri: ["'none'"], formAction: ["'self'"], frameAncestors: ["'none'"],
        ...(prod ? { upgradeInsecureRequests: [] } : {}),
      },
    },
  }));
  app.use(express.json({ limit: '20kb' }));

  const log = (u, action, pid, detail) =>
    db.prepare('INSERT INTO audit(ts,username,action,patient_id,detail) VALUES(?,?,?,?,?)')
      .run(Date.now(), u ? u.username : null, action, pid || null, detail ? String(detail).slice(0, 200) : null);

  // API-wide guards: no caching, and CSRF defence for anything that changes state
  // (custom header + same-origin check; the session cookie is also SameSite=Strict).
  app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      let ok = req.get('x-requested-with') === 'oncomitra';
      const o = req.get('origin');
      if (ok && o) { try { ok = new URL(o).host === req.get('host'); } catch { ok = false; } }
      if (!ok) return res.status(403).json({ error: 'Bad request origin' });
    }
    next();
  });
  app.use('/api', rateLimit({ windowMs: 60e3, limit: 300, standardHeaders: true, legacyHeaders: false }));

  function auth(req, res, next) {
    const c = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith('sid='));
    if (c) {
      const th = H(c.slice(4)), now = Date.now();
      const r = db.prepare('SELECT s.created, s.last_seen, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?').get(th);
      if (r && now - r.created < ABSOLUTE && now - r.last_seen < IDLE) {
        db.prepare('UPDATE sessions SET last_seen=? WHERE token_hash=?').run(now, th);
        req.user = r; req.th = th; return next();
      }
      if (r) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(th);
    }
    res.status(401).json({ error: 'Not signed in' });
  }
  const need = p => (req, res, next) => PERMS[req.user.role][p] ? next()
    : (log(req.user, 'denied:' + p), res.status(403).json({ error: 'Not allowed' }));
  const pub = u => ({ username: u.username, displayName: u.display_name, role: u.role });

  // ---- authentication ----
  const loginLimiter = rateLimit({ windowMs: 15 * 60e3, limit: loginRateMax, standardHeaders: true, legacyHeaders: false,
    message: { error: 'Too many attempts. Try again later.' } });
  app.post('/api/login', loginLimiter, async (req, res, next) => {
    try {
      const bad = () => res.status(401).json({ error: 'Invalid credentials' });
      const b = req.body || {};
      const u = clean(b.username, 1, 64);
      const pw = typeof b.password === 'string' && b.password.length > 0 && b.password.length <= 200 ? b.password : null;
      if (!u || !pw) return bad();
      const row = db.prepare('SELECT * FROM users WHERE username=?').get(u), now = Date.now();
      if (row && row.locked_until > now) { log(row, 'login_locked'); return bad(); }
      const ok = await verifyPassword(pw, row && row.pw_hash);
      if (!row || !ok) {
        if (row) {
          const f = row.failed + 1;
          db.prepare('UPDATE users SET failed=?, locked_until=? WHERE id=?').run(f >= MAX_FAIL ? 0 : f, f >= MAX_FAIL ? now + LOCK : 0, row.id);
        }
        log(row || { username: u }, 'login_failed');
        return bad();
      }
      db.prepare('UPDATE users SET failed=0, locked_until=0 WHERE id=?').run(row.id);
      const token = crypto.randomBytes(32).toString('base64url');
      db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(H(token), row.id, now, now);
      res.cookie('sid', token, { httpOnly: true, sameSite: 'strict', secure: prod, path: '/', maxAge: ABSOLUTE });
      log(row, 'login');
      res.json({ user: pub(row) });
    } catch (e) { next(e); }
  });
  app.post('/api/logout', auth, (req, res) => {
    db.prepare('DELETE FROM sessions WHERE token_hash=?').run(req.th);
    log(req.user, 'logout');
    res.clearCookie('sid', { path: '/' }).json({ ok: true });
  });
  app.get('/api/me', auth, (req, res) => res.json({ user: pub(req.user) }));

  // ---- patients (row-level access: ASHA workers only ever see their own patients) ----
  function getPatients(u, id) {
    let sql = 'SELECT p.*, a.display_name AS asha FROM patients p JOIN users a ON a.id=p.asha_id WHERE 1=1';
    const args = [];
    if (!PERMS[u.role].all) { sql += ' AND p.asha_id=?'; args.push(u.id); }
    if (id) { sql += ' AND p.id=?'; args.push(id); }
    return db.prepare(sql + ' ORDER BY p.updated DESC').all(...args);
  }
  const shape = p => ({
    id: p.id, name: p.name, age: p.age, gender: p.gender, village: p.village, asha: p.asha, risk: p.risk, habit: p.habit,
    stageIdx: p.stage_idx, updated: new Date(p.updated).toISOString(), symptoms: JSON.parse(p.symptoms),
    notes: db.prepare('SELECT text FROM notes WHERE patient_id=? ORDER BY ts DESC, id DESC').all(p.id).map(n => n.text),
  });

  app.get('/api/patients', auth, (req, res) => {
    const rows = getPatients(req.user);
    log(req.user, 'list_patients', null, rows.length + ' records');
    res.json({ patients: rows.map(shape) });
  });

  app.post('/api/patients', auth, (req, res) => {
    const b = req.body || {};
    const name = clean(b.name, 1, 80), village = clean(b.village, 1, 60), habit = clean(b.habit, 1, 60);
    const syms = Array.isArray(b.symptoms) && b.symptoms.length <= 10 ? b.symptoms.map(s => clean(s, 1, 60)) : null;
    if (!name || !village || !habit || !syms || syms.includes(null) ||
        !Number.isInteger(b.age) || b.age < 0 || b.age > 120 ||
        !Number.isInteger(b.risk) || b.risk < 0 || b.risk > 100 ||
        !['Female', 'Male', 'Other'].includes(b.gender)) return res.status(400).json({ error: 'Invalid patient data' });
    let asha = req.user;
    if (req.user.role !== 'asha') { // clinicians/admins choose an ASHA worker; ASHA workers can only assign to themselves
      asha = db.prepare("SELECT * FROM users WHERE role='asha' AND display_name=?").get(clean(b.asha, 1, 80) || '');
      if (!asha) return res.status(400).json({ error: 'Unknown ASHA worker' });
    }
    const id = 'p' + crypto.randomBytes(6).toString('hex');
    db.prepare('INSERT INTO patients VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(id, name, b.age, b.gender, village, asha.id, b.risk, habit, 2, JSON.stringify(syms), Date.now());
    log(req.user, 'create_patient', id);
    res.status(201).json({ patient: shape(getPatients(req.user, id)[0]) });
  });

  app.post('/api/patients/:id/notes', auth, (req, res) => {
    const p = getPatients(req.user, req.params.id)[0];
    if (!p) return res.status(404).json({ error: 'Not found' }); // 404, not 403, so IDs cannot be probed
    const text = clean(req.body && req.body.text, 1, 1000);
    if (!text) return res.status(400).json({ error: 'Invalid note' });
    db.prepare('INSERT INTO notes(patient_id,author,text,ts) VALUES(?,?,?,?)').run(p.id, req.user.username, text, Date.now());
    db.prepare('UPDATE patients SET updated=? WHERE id=?').run(Date.now(), p.id);
    log(req.user, 'add_note', p.id);
    res.status(201).json({ ok: true });
  });

  app.patch('/api/patients/:id/stage', auth, need('stage'), (req, res) => {
    const p = getPatients(req.user, req.params.id)[0];
    const s = req.body && req.body.stageIdx;
    if (!p) return res.status(404).json({ error: 'Not found' });
    if (!Number.isInteger(s) || s < 0 || s > 6) return res.status(400).json({ error: 'Invalid stage' });
    db.prepare('UPDATE patients SET stage_idx=?, updated=? WHERE id=?').run(s, Date.now(), p.id);
    log(req.user, 'change_stage', p.id, 'to ' + s);
    res.json({ ok: true });
  });

  const cell = v => { let s = String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  app.get('/api/export.csv', auth, need('export'), (req, res) => {
    const rows = getPatients(req.user);
    const body = ['Name,Age,Gender,Village,ASHA,Risk,Stage,LastUpdate', ...rows.map(p =>
      [p.name, p.age, p.gender, p.village, p.asha, p.risk, p.stage_idx, new Date(p.updated).toISOString().slice(0, 10)].map(cell).join(','))].join('\n');
    log(req.user, 'export_csv', null, rows.length + ' records');
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="oncomitra_patients.csv"' }).send(body);
  });

  app.get('/api/audit', auth, need('audit'), (req, res) =>
    res.json({ entries: db.prepare('SELECT ts, username, action, patient_id FROM audit ORDER BY id DESC LIMIT 200').all() }));

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
  app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html' }));
  app.use((err, req, res, next) => { // no stack traces or internals in responses
    const status = err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 413 ? 'Request too large' : status === 500 ? 'Server error' : 'Bad request' });
  });
  return app;
}
module.exports = { createApp };
