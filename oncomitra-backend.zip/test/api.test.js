'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createApp } = require('../src/app');
const { seed } = require('../src/seed');

let db, server, base, pids;
const USERS = [
  { username: 'admin', displayName: 'Admin', role: 'admin', password: 'admin-pass-123' },
  { username: 'doc', displayName: 'Dr. Rao', role: 'clinician', password: 'doc-pass-123' },
  { username: 'a1', displayName: 'Sunita Devi', role: 'asha', password: 'asha1-pass-123' },
  { username: 'a2', displayName: 'Radha Kumari', role: 'asha', password: 'asha2-pass-123' },
];
const HDR = { 'Content-Type': 'application/json', 'X-Requested-With': 'oncomitra' };

async function call(method, path, { body, cookie, headers } = {}) {
  const r = await fetch(base + path, { method, headers: { ...HDR, ...(cookie ? { Cookie: cookie } : {}), ...headers },
    body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body) });
  const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch {}
  return { status: r.status, json, text, headers: r.headers };
}
async function login(username, password) {
  const r = await call('POST', '/api/login', { body: { username, password } });
  const c = r.headers.get('set-cookie');
  return { r, cookie: c ? c.split(';')[0] : null };
}
const patient = (o = {}) => ({ name: 'Test Patient', age: 45, gender: 'Female', village: 'Kaithal', asha: 'Sunita Devi', risk: 60, habit: 'None', symptoms: [], ...o });

before(async () => {
  db = openDb(':memory:');
  await seed(db, USERS, { demoPatients: false });
  server = createApp({ db, loginRateMax: 1000 }).listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

test('unauthenticated requests are rejected', async () => {
  for (const p of ['/api/patients', '/api/me', '/api/audit', '/api/export.csv']) assert.equal((await call('GET', p)).status, 401);
});

test('login sets a hardened cookie and never returns the hash', async () => {
  const { r } = await login('doc', 'doc-pass-123');
  assert.equal(r.status, 200);
  const sc = r.headers.get('set-cookie');
  assert.match(sc, /HttpOnly/i); assert.match(sc, /SameSite=Strict/i);
  assert.ok(!r.text.includes('scrypt'));
});

test('wrong password gives a generic error; 5 failures lock the account even for the right password', async () => {
  const unknown = await login('nobody', 'x');
  const wrong = await login('a2', 'wrong-1');
  assert.equal(unknown.r.status, 401); assert.equal(wrong.r.status, 401);
  assert.deepEqual(unknown.r.json, wrong.r.json);
  for (let i = 0; i < 4; i++) await login('a2', 'wrong-again');
  const locked = await login('a2', 'asha2-pass-123');
  assert.equal(locked.r.status, 401);
  assert.equal(locked.cookie, null);
});

test('IP-level login rate limit returns 429', async () => {
  const d = openDb(':memory:'); await seed(d, USERS, { demoPatients: false });
  const s = createApp({ db: d, loginRateMax: 3 }).listen(0);
  const b = `http://127.0.0.1:${s.address().port}`;
  const codes = [];
  for (let i = 0; i < 5; i++) codes.push((await fetch(b + '/api/login', { method: 'POST', headers: HDR, body: JSON.stringify({ username: 'x', password: 'y' }) })).status);
  s.close();
  assert.deepEqual(codes, [401, 401, 401, 429, 429]);
});

test('CSRF guard: state-changing request without the custom header or with a foreign Origin is refused', async () => {
  const { cookie } = await login('doc', 'doc-pass-123');
  const noHdr = await fetch(base + '/api/patients', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: JSON.stringify(patient()) });
  assert.equal(noHdr.status, 403);
  const foreign = await call('POST', '/api/patients', { cookie, body: patient(), headers: { Origin: 'https://evil.example' } });
  assert.equal(foreign.status, 403);
});

test('ASHA workers cannot read or modify another ASHA worker\'s patients', async () => {
  const a1 = (await login('a1', 'asha1-pass-123')).cookie;
  const doc = (await login('doc', 'doc-pass-123')).cookie;
  const mine = await call('POST', '/api/patients', { cookie: a1, body: patient({ name: 'Mine' }) });
  const theirs = await call('POST', '/api/patients', { cookie: doc, body: patient({ name: 'Theirs', asha: 'Radha Kumari' }) });
  assert.equal(mine.status, 201); assert.equal(theirs.status, 201);
  const list = (await call('GET', '/api/patients', { cookie: a1 })).json.patients.map(p => p.name);
  assert.ok(list.includes('Mine')); assert.ok(!list.includes('Theirs'));
  const note = await call('POST', `/api/patients/${theirs.json.patient.id}/notes`, { cookie: a1, body: { text: 'hi' } });
  assert.equal(note.status, 404);
  const docList = (await call('GET', '/api/patients', { cookie: doc })).json.patients.map(p => p.name);
  assert.ok(docList.includes('Mine') && docList.includes('Theirs'));
});

test('role enforcement is server-side: ASHA cannot change stage, export or read the audit log', async () => {
  const a1 = (await login('a1', 'asha1-pass-123')).cookie;
  const id = (await call('POST', '/api/patients', { cookie: a1, body: patient() })).json.patient.id;
  assert.equal((await call('PATCH', `/api/patients/${id}/stage`, { cookie: a1, body: { stageIdx: 4 } })).status, 403);
  assert.equal((await call('GET', '/api/export.csv', { cookie: a1 })).status, 403);
  assert.equal((await call('GET', '/api/audit', { cookie: a1 })).status, 403);
  const doc = (await login('doc', 'doc-pass-123')).cookie;
  assert.equal((await call('PATCH', `/api/patients/${id}/stage`, { cookie: doc, body: { stageIdx: 4 } })).status, 200);
  assert.equal((await call('GET', '/api/audit', { cookie: doc })).status, 403); // clinicians cannot read audit either
});

test('clinician CSV export neutralises formulas and quotes commas', async () => {
  const doc = (await login('doc', 'doc-pass-123')).cookie;
  await call('POST', '/api/patients', { cookie: doc, body: patient({ name: '=1+1, "x"' }) });
  const r = await call('GET', '/api/export.csv', { cookie: doc });
  assert.equal(r.status, 200);
  assert.ok(r.text.includes(`"'=1+1, ""x"""`));
});

test('input validation and size limits', async () => {
  const doc = (await login('doc', 'doc-pass-123')).cookie;
  for (const bad of [{ age: -1 }, { age: 'x' }, { risk: 101 }, { gender: 'Robot' }, { name: '' }, { symptoms: 'no' }, { asha: 'Nobody' }])
    assert.equal((await call('POST', '/api/patients', { cookie: doc, body: patient(bad) })).status, 400, JSON.stringify(bad));
  const big = await call('POST', '/api/patients', { cookie: doc, body: JSON.stringify({ name: 'x'.repeat(50000) }) });
  assert.equal(big.status, 413);
  const badJson = await call('POST', '/api/patients', { cookie: doc, body: '{not json' });
  assert.equal(badJson.status, 400);
  assert.ok(!/at .*\.js/.test(badJson.text)); // no stack traces
});

test('XSS payloads are stored as inert data and returned as JSON', async () => {
  const doc = (await login('doc', 'doc-pass-123')).cookie;
  const p = '<img src=x onerror=alert(1)>';
  const r = await call('POST', '/api/patients', { cookie: doc, body: patient({ name: p }) });
  assert.equal(r.status, 201);
  assert.match(r.headers.get('content-type'), /application\/json/);
  assert.equal(r.json.patient.name, p);
});

test('logout destroys the session on the server', async () => {
  const { cookie } = await login('doc', 'doc-pass-123');
  assert.equal((await call('GET', '/api/me', { cookie })).status, 200);
  assert.equal((await call('POST', '/api/logout', { cookie })).status, 200);
  assert.equal((await call('GET', '/api/me', { cookie })).status, 401); // old cookie is useless
});

test('audit log records who did what', async () => {
  const admin = (await login('admin', 'admin-pass-123')).cookie;
  const r = await call('GET', '/api/audit', { cookie: admin });
  assert.equal(r.status, 200);
  const acts = r.json.entries.map(e => e.action);
  for (const a of ['login', 'login_failed', 'create_patient', 'change_stage', 'export_csv', 'logout', 'denied:stage']) assert.ok(acts.includes(a), a);
});

test('security headers are present and no framework banner leaks', async () => {
  const r = await fetch(base + '/');
  assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(r.headers.get('x-powered-by'), null);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
});
